package com.phiteam.timeguessr;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TimeguessrApplicationTests {

	@Test
	void contextLoads() {
	}

}
