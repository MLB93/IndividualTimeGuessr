package com.phiteam.timeguessr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TimeguessrApplication {

	public static void main(String[] args) {
		SpringApplication.run(TimeguessrApplication.class, args);
	}

}
